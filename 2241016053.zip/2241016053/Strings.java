public class Strings {
    String msg_1 = "Enter the number of employee you want add in the database :";
    String name = "Enter your name : ";
    String emp_id = "Enter employee ID: ";
    String salary = "Enter your salary: ";
    String hireDate = "Enter your hire date: ";
    String jobPosition = "Enter job position: ";
    String contactNumber = "Enter contact number: ";
    String address = "---------Enter your address-------- ";

    // address messages

    String city = "Enter your city: ", state = "Enter your state: ", nationality = "Enter your nationality: ",
            pin = "Enter your pin-code: ", landmark = "Enter your landmark: ",
            countryCode = "Enter your country code: ";

    public static void printer(String s) {
        System.out.println(s);
    }
}
